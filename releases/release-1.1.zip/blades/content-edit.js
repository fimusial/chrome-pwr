export function blade_contentEditOn() {
    document.body.contentEditable = 'true';
}

export function blade_contentEditOff() {
    document.body.contentEditable = 'false';
}
